#!/bin/bash

echo "Hello world"

# user defined variable

name="nitheesh"

echo "This is done by "$name

echo The current user is $USER

#read -p " $name what is your fullname?" fullname

#echo so your full name is $fullname


